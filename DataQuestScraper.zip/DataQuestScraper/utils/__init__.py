# Initialize utils module
